package com.hostel.allocator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AllocatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
