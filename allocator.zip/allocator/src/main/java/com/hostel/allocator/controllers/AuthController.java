package com.hostel.allocator.controllers;

import com.hostel.allocator.dto.LoginRequest;
import com.hostel.allocator.models.Role;
import com.hostel.allocator.models.User;
import com.hostel.allocator.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    // STUDENT REGISTRATION
    @PostMapping("/register")
    public ResponseEntity<?> registerStudent(@RequestBody User newUser) {
        // Ensure role is set to STUDENT
        newUser.setRole(Role.STUDENT);
        
        // Check if email already exists
        if (userRepository.findByEmail(newUser.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is already in use.");
        }

        User savedUser = userRepository.save(newUser);
        return ResponseEntity.ok(savedUser);
    }

    // LOGIN (for both Student and Warden)
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        Optional<User> userOptional = userRepository.findByEmail(loginRequest.getEmail());

        if (userOptional.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password.");
        }

        User user = userOptional.get();

        // !!! INSECURE - FOR DEMO ONLY !!!
        // In a real app, you would hash and check the password.
        if (!user.getPassword().equals(loginRequest.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password.");
        }

        // Login successful, return user details
        return ResponseEntity.ok(user);
    }
}