package com.hostel.allocator.controllers;

import com.hostel.allocator.models.Allocation;
import com.hostel.allocator.models.User;
import com.hostel.allocator.repositories.AllocationRepository;
import com.hostel.allocator.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/student")
public class StudentController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AllocationRepository allocationRepository;

    // GET MY DETAILS AND MY ROOM
    @GetMapping("/{studentId}/details")
    public ResponseEntity<?> getMyDetails(@PathVariable Integer studentId) {
        Optional<User> userOptional = userRepository.findById(studentId);
        if (userOptional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        User user = userOptional.get();

        // Find their allocation
        Optional<Allocation> allocationOptional = allocationRepository.findByUser(user);

        // Return a simple map with all details
        // (You could create a DTO for this)
        var details = new java.util.HashMap<String, Object>();
        details.put("user", user);
        details.put("allocation", allocationOptional.orElse(null));

        return ResponseEntity.ok(details);
    }
}