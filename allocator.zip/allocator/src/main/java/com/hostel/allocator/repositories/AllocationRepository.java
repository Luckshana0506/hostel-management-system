package com.hostel.allocator.repositories;

import com.hostel.allocator.models.Allocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hostel.allocator.models.User;
import java.util.Optional;

@Repository
public interface AllocationRepository extends JpaRepository<Allocation, Integer> {
    Optional<Allocation> findByUser(User user);
}