package com.hostel.allocator.repositories;

import com.hostel.allocator.models.User;
import com.hostel.allocator.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    
    // Custom query to find students who match the filter AND are not yet allocated
    @Query("SELECT u FROM User u WHERE u.role = :role AND u.studentYear = :year AND u.studentCourse = :course AND u.userId NOT IN (SELECT a.user.userId FROM Allocation a)")
    List<User> findUnallocatedStudentsByFilter(Role role, int year, String course);
    Optional<User> findByEmail(String email);
}