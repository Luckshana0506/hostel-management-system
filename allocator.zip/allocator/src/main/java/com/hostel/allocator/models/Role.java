package com.hostel.allocator.models;

public enum Role {
    STUDENT,
    WARDEN
}