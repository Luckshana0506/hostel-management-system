package com.hostel.allocator.models;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "allocations")
public class Allocation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer allocationId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "room_id")
    private Room room;

    private LocalDateTime allocatedOn;
    
    // Getters and Setters...
    public Integer getAllocationId() {
        return allocationId;
    }
    public void setAllocationId(Integer allocationId) {
        this.allocationId = allocationId;
    }
    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }
    public Room getRoom() {
        return room;
    }
    public void setRoom(Room room) {
        this.room = room;
    }
    public LocalDateTime getAllocatedOn() {
        return allocatedOn;
    }
    public void setAllocatedOn(LocalDateTime allocatedOn) {
        this.allocatedOn = allocatedOn;
    }
}