package com.hostel.allocator.services;

import com.hostel.allocator.models.Allocation;
import com.hostel.allocator.models.Role;
import com.hostel.allocator.models.Room;
import com.hostel.allocator.models.User;
import com.hostel.allocator.repositories.AllocationRepository;
import com.hostel.allocator.repositories.RoomRepository;
import com.hostel.allocator.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AllocationService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private AllocationRepository allocationRepository;

    public void runAllocation(String course, int year) {
        // 1. Find students who need a room
        List<User> studentsToAllocate = userRepository.findUnallocatedStudentsByFilter(Role.STUDENT, year, course);

        // 2. Find rooms that have space
        List<Room> availableRooms = roomRepository.findByCurrentOccupancyLessThan(Integer.MAX_VALUE); // Simplified query

        // 3. Simple allocation logic
        for (User student : studentsToAllocate) {
            for (Room room : availableRooms) {
                if (room.getCurrentOccupancy() < room.getCapacity()) {
                    // 4. Allocate!
                    Allocation newAllocation = new Allocation();
                    newAllocation.setUser(student);
                    newAllocation.setRoom(room);
                    newAllocation.setAllocatedOn(LocalDateTime.now());
                    allocationRepository.save(newAllocation);

                    // 5. Update room occupancy
                    room.setCurrentOccupancy(room.getCurrentOccupancy() + 1);
                    roomRepository.save(room);

                    // Break from inner loop once student is allocated
                    break;
                }
            }
        }
    }
    public Allocation assignRoomToStudent(Integer userId, Integer roomId) {
        // 1. Find the student and room
        User student = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Student not found with ID: " + userId));

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found with ID: " + roomId));

        // 2. Check if student is already allocated
        Optional<Allocation> existingAllocation = allocationRepository.findByUser(student);
        if (existingAllocation.isPresent()) {
            throw new RuntimeException("Student is already allocated to room " +
                    existingAllocation.get().getRoom().getRoomNumber());
        }

        // 3. Check if room is full
        if (room.getCurrentOccupancy() >= room.getCapacity()) {
            throw new RuntimeException("Room " + room.getRoomNumber() + " is full.");
        }

        // 4. Create and save new allocation
        Allocation newAllocation = new Allocation();
        newAllocation.setUser(student);
        newAllocation.setRoom(room);
        newAllocation.setAllocatedOn(LocalDateTime.now());
        allocationRepository.save(newAllocation);

        // 5. Update room occupancy
        room.setCurrentOccupancy(room.getCurrentOccupancy() + 1);
        roomRepository.save(room);

        return newAllocation;
    }
}