package com.hostel.allocator.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hostel.allocator.models.Allocation;
import com.hostel.allocator.models.Room;
import com.hostel.allocator.repositories.RoomRepository;
import com.hostel.allocator.services.AllocationService;

@RestController
@RequestMapping("/api/warden")
public class WardenController {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private AllocationService allocationService;

    // Module 1: Room Directory
    @GetMapping("/rooms")
    public List<Room> getRoomDirectory() {
        return roomRepository.findAll();
    }

    // Module 2 & 6: Allocation Engine with Filter
    @PostMapping("/run-allocation")
    public ResponseEntity<String> runAllocation(
            @RequestParam String course,
            @RequestParam int year) {
        
        allocationService.runAllocation(course, year);
        return ResponseEntity.ok("Allocation process completed for " + course + " Year " + year);
    }

    // Module 4: Occupancy Report (We can use the same /rooms endpoint for a simple report)
    @GetMapping("/report/occupancy")
    public List<Room> getOccupancyReport() {
        return roomRepository.findAll(); // For now, the report is just the list of rooms
    }

    // --- NEW ENDPOINT FOR MANUAL ALLOCATION ---
    @PostMapping("/assign-room")
    public ResponseEntity<?> assignRoom(
            @RequestParam Integer studentId,
            @RequestParam Integer roomId) {
        try {
            Allocation allocation = allocationService.assignRoomToStudent(studentId, roomId);
            return ResponseEntity.ok(allocation);
        } catch (RuntimeException e) {
            // Return a 400 Bad Request with the error message
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}