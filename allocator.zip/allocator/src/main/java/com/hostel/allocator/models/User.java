package com.hostel.allocator.models;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userId;

    private String name;
    private String email;
    private String password;

    @Enumerated(EnumType.STRING)
    private Role role;

    private Integer studentYear;
    private String studentCourse;
    
    // Getters and Setters...
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public Role getRole() {
        return role;
    }
    public void setRole(Role role) {
        this.role = role;
    }
    public Integer getStudentYear() {
        return studentYear;
    }
    public void setStudentYear(Integer studentYear) {
        this.studentYear = studentYear;
    }
    public String getStudentCourse() {
        return studentCourse;
    }
    public void setStudentCourse(String studentCourse) {
        this.studentCourse = studentCourse;
    }
}