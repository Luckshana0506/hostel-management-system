Hostel Room Allocation System
A full-stack web application designed to manage and automate the process of allocating hostel rooms to students. It provides separate, role-based dashboards for wardens (admin) and students, powered by a Java Spring Boot backend and a MySQL database.

✨ Features
Warden (Admin)
Secure Login: Separate login for wardens.

Warden Dashboard: A central panel to manage all allocation tasks.

Batch Allocation: Automatically assign rooms to students based on filters like course and year.

Manual Assignment: Manually assign a specific room to a specific student.

Occupancy Report: View a live report of all rooms, their capacity, and current occupancy.

Student
Student Registration: New students can create a secure account.

Secure Login: Students can log in to their personal dashboard.

Student Dashboard: View personal details (name, course, year).

Check Allocation: View the specific room number they have been allocated.

🛠️ Tech Stack
🖥️ Frontend
HTML5

CSS3 (with inline styles)

JavaScript (ES6+) (for API calls with fetch)

⚙️ Backend
Java 17

Spring Boot

Spring Web: For creating REST APIs.

Spring Data JPA: For database communication.

Maven: For dependency management.

🗃️ Database
MySQL 8

🚀 Getting Started
Follow these steps to get the project running on your local machine.

1. Prerequisites
Java 17+ (JDK)

Apache Maven

MySQL Server & MySQL Workbench (or any SQL client)

An IDE like IntelliJ IDEA or VS Code

2. Database Setup
Open MySQL Workbench and connect to your database.

Create a new database (schema) for the project:

SQL

CREATE DATABASE IF NOT EXISTS hostel_db;
Use the new database:

SQL

USE hostel_db;
Run the following SQL script to create all the necessary tables and add a sample warden.

SQL

-- 1. Create the 'rooms' table
CREATE TABLE rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    capacity INT NOT NULL,
    current_occupancy INT NOT NULL DEFAULT 0
);

-- 2. Create the 'users' table (for Students and Wardens)
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('STUDENT', 'WARDEN') NOT NULL,
    student_year INT NULL,
    student_course VARCHAR(50) NULL
);

-- 3. Create the 'allocations' mapping table
CREATE TABLE allocations (
    allocation_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    room_id INT NOT NULL,
    allocated_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (room_id) REFERENCES rooms(room_id)
);

-- 4. Add sample rooms
INSERT INTO rooms (room_number, capacity) VALUES
('101A', 3),
('102A', 3),
('201B', 2);

-- 5. Add the default WARDEN
INSERT INTO users (name, email, password, role) VALUES
('Warden Dave', 'dave@school.edu', 'wardenpass', 'WARDEN');
3. Backend Configuration
Open the project in your IDE.

Navigate to src/main/resources/application.properties.

Make sure the database connection details match your MySQL setup. (The username is often root).

Properties

# MySQL Database Connection
spring.datasource.url=jdbc:mysql://localhost:3306/hostel_db
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD

# JPA Settings
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
4. Run the Application
Find the main application file: src/main/java/com/hostel/allocator/AllocatorApplication.java.

Right-click and Run the file.

Your server will start on http://localhost:8080.

5. Access the Application
Open your web browser.

Navigate to the login page: http://localhost:8080/login.html

Test Credentials:

Warden:

Email: dave@school.edu

Password: wardenpass

Student:

Go to http://localhost:8080/register.html to create a new student account.